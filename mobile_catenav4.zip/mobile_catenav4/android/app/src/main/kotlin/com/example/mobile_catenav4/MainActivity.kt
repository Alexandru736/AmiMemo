package com.example.mobile_catenav4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
